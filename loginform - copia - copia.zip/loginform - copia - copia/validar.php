<?php
    //guarda los datos del formulario en las variables
    $user=$_POST ['user'];
    $password=$_POST['password'];
    // conectar a la base de datos
    $conexion=mysqli_connect("localhost", "root", "", "bdingreso");
    $consulta="SELECT * FROM usuarios WHERE usuario='$user' AND clave='$password'";  
    $resultado=mysqli_query($conexion,$consulta);

    $filas=mysqli_num_rows($resultado);
    if ($filas>0) {
        header("location:sistema de riego_html.html");
    }
    else {
        echo "Error de autentificaciòn";  
    }
    mysqli_free_result($resultado);
    mysqli_close($conexion);

